package com.example.TaskManager.models;
import jakarta.persistence.*;
@Entity
@Table(name="Tasks")
public class Tasks {
@Id
@Column(name="taskid")
private Long taskid;
@Column(name="tasktitle")
private String title;
@Column(name="taskdesc")
private String desc;
@Column(name="duedate")
private String duedate;
@Column(name="taskstatus")
private String taskstatus;
@JoinColumn(name="userid")
private Long userid;
public Long getTaskid() {
	return taskid;
}
public void setTaskid(Long taskid) {
	this.taskid = taskid;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getDesc() {
	return desc;
}
public void setDesc(String desc) {
	this.desc = desc;
}
public String getDuedate() {
	return duedate;
}
public void setDuedate(String duedate) {
	this.duedate = duedate;
}
public String getTaskstatus() {
	return taskstatus;
}
public void setTaskstatus(String taskstatus) {
	this.taskstatus = taskstatus;
}
public Long getUserid() {
	return userid;
}
public void setUserid(Long userid) {
	this.userid = userid;
}

}
