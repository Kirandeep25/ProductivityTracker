package com.example.TaskManager.models;
import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(name="UsersForTaskManagement")
public class User {
@Id
@Column(name="userid")
private Long userid;
@Column(name="username")
private String username;
@Column(name="password")
private String password;
@OneToMany(mappedBy="userid", cascade=CascadeType.ALL)
private List<Tasks> tasks;
public Long getUserid() {
	return userid;
}
public void setUserid(Long userid) {
	this.userid = userid;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public List<Tasks> getTasks() {
	return tasks;
}
public void setTasks(List<Tasks> tasks) {
	this.tasks = tasks;
}

}
