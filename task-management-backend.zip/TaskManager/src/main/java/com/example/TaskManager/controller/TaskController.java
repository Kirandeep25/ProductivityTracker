package com.example.TaskManager.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.TaskManager.models.Tasks;
import com.example.TaskManager.models.User;
import com.example.TaskManager.repository.TaskRepository;
import com.example.TaskManager.repository.UserRepository;

@RestController
@RequestMapping("/tasks")
@CrossOrigin("http://localhost:4200")
public class TaskController {
	@Autowired
    private TaskRepository taskrep;

    @Autowired
    private UserRepository userrep;

    @GetMapping("/{userid}")
    public ResponseEntity<List<Tasks>> getTasksForUser(@PathVariable Long userid) {
        if (!userrep.existsById(userid)) {
            return ResponseEntity.badRequest().body(null);
        }
        return ResponseEntity.ok(taskrep.findByUserid(userid));
    }

    @PostMapping("/{userid}")
    public ResponseEntity<Tasks> addTaskForUser(@PathVariable Long userid, @RequestBody Tasks task) {
        return userrep.findById(userid).map(user -> {
            task.setUserid(userid);
            Tasks savedTask = taskrep.save(task);
            return ResponseEntity.ok(savedTask);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }


    @PutMapping("/{userid}/{taskid}")
    public ResponseEntity<String> updateTask(@PathVariable Long userid, @PathVariable Long taskid, @RequestBody Tasks updatedTask) {
        Optional<User> userOptional = userrep.findById(userid);
        if (userOptional.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found!");
        }

        Optional<Tasks> taskOptional = taskrep.findById(taskid);
        if (taskOptional.isEmpty() || !taskOptional.get().getUserid().equals(userid)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Task not found or does not belong to this user!");
        }

        Tasks task = taskOptional.get();
        task.setTitle(updatedTask.getTitle());
        task.setDesc(updatedTask.getDesc());
        task.setDuedate(updatedTask.getDuedate());
        task.setTaskstatus(updatedTask.getTaskstatus());

        taskrep.save(task);
        return ResponseEntity.ok("Task updated successfully!");
    }

    @DeleteMapping("/{userid}/{taskid}")
    public ResponseEntity<String> deleteTask(@PathVariable Long userid, @PathVariable Long taskid) {
        Optional<User> userOptional = userrep.findById(userid);
        if (userOptional.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found!");
        }

        Optional<Tasks> taskOptional = taskrep.findById(taskid);
        if (taskOptional.isEmpty() || !taskOptional.get().getUserid().equals(userid)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Task not found or does not belong to this user!");
        }

        taskrep.deleteById(taskid);
        return ResponseEntity.ok("Task deleted successfully!");
    }
}
