package com.example.TaskManager.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.TaskManager.models.Tasks;

public interface TaskRepository extends JpaRepository<Tasks, Long> {
   public List<Tasks> findByUserid(Long userid);
}
